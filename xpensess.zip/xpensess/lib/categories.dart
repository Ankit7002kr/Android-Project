import 'package:flutter/material.dart';
import 'package:xpense/page 2.dart'; // Corrected import for page_2.dart

class CategoriesPage extends StatelessWidget {
  final String selectedCurrency; // Field to store selected currency
  final String uid; // Field to store uid

  const CategoriesPage({Key? key, required this.selectedCurrency, required this.uid}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background image (ensure this image exists in your assets)
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/img_16.png'), // Ensure this image is in your assets
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Categories grid
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                const SizedBox(height: 50), // Top spacing
                const Text(
                  'Categories',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white, // Adjust color based on background
                    fontFamily: 'Times New Roman',
                  ),
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: GridView.count(
                    crossAxisCount: 2, // Two categories per row
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    children: [
                      _buildCategoryButton(context, 'Food', Icons.fastfood, Colors.red),
                      _buildCategoryButton(context, 'Transport', Icons.directions_bus, Colors.blue),
                      _buildCategoryButton(context, 'Shopping', Icons.shopping_cart, Colors.green),
                      _buildCategoryButton(context, 'Entertainment', Icons.movie, Colors.orange),
                      _buildCategoryButton(context, 'Bills', Icons.receipt, Colors.purple),
                      _buildCategoryButton(context, 'Health', Icons.health_and_safety, Colors.teal),
                      _buildCategoryButton(context, 'Travel', Icons.airplanemode_active, Colors.lightBlue),
                      _buildCategoryButton(context, 'Education', Icons.school, Colors.yellow),
                      _buildCategoryButton(context, 'Groceries', Icons.store, Colors.brown),
                      _buildCategoryButton(context, 'Gifts', Icons.card_giftcard, Colors.pink),
                      _buildCategoryButton(context, 'Personal Care', Icons.favorite, Colors.purpleAccent),
                      _buildCategoryButton(context, 'Miscellaneous', Icons.category, Colors.cyan),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Helper function to build a category button
  Widget _buildCategoryButton(BuildContext context, String title, IconData icon, Color color) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white.withOpacity(0.8), // Button background color
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        elevation: 4,
      ),
      onPressed: () {
        // Navigate to Page2 when a category is selected
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Page2(), // Navigates to Page2 (expense entry form)
          ),
        );
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 50,
            color: color,
          ),
          const SizedBox(height: 10),
          Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Times New Roman',
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  // Handle category selection (this function can be modified or removed)
  void _onCategorySelected(String category) {
    print('Selected category: $category'); // Replace with actual logic if needed
  }
}
