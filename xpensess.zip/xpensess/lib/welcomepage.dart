import 'package:flutter/material.dart';
import 'package:http/http.dart' as http; // Import http package
import 'dart:convert'; // Import for json decoding
import 'categories.dart'; // Import the CategoriesPage

class WelcomePage extends StatefulWidget {
  final String uid;

  const WelcomePage({Key? key, required this.uid}) : super(key: key);

  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> with SingleTickerProviderStateMixin {
  String? _selectedCurrency; // Change to nullable
  String _selectedBudgetType = 'Monthly';
  bool _dailySummary = false;
  bool _weeklyStatus = false;
  bool _monthlyAnalysis = false;
  bool _categorizeExpenses = false;
  bool _setSpendingLimits = false;
  bool _trackIncomeSources = false;
  bool _createRecurringExpenses = false;
  bool _exportData = false;

  late AnimationController _controller;
  late Animation<double> _opacityAnimation;

  List<String> _currencies = []; // List to store currency options

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    )..forward();

    _opacityAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeIn,
      ),
    );

    _fetchCurrencyData(); // Fetch currency data from API
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // Method to fetch currency data from an API
  Future<void> _fetchCurrencyData() async {
    try {
      final response = await http.get(Uri.parse('https://api.exchangerate-api.com/v4/latest/USD')); // Example API
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        final rates = data['rates'] as Map<String, dynamic>;

        // Map the rates to a list of strings in the format 'Currency - Country'
        setState(() {
          _currencies = rates.keys.map((currency) {
            return '$currency - ${currency} Currency';
          }).toList();
        });
      } else {
        throw Exception('Failed to load currencies');
      }
    } catch (error) {
      print('Error fetching currency data: $error');
    }
  }

  // Method to create animated widgets
  Widget _buildAnimatedSection(Widget child, {int delay = 0}) {
    return FadeTransition(
      opacity: Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(
          parent: _controller,
          curve: Interval(0.1 * delay, 1, curve: Curves.easeIn),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: child,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Xpenses",
          style: TextStyle(
            fontFamily: 'Times New Roman',
            fontWeight: FontWeight.bold,
            fontSize: 30,
          ),
        ),
        backgroundColor: Colors.red,
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/img_10.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildAnimatedSection(
                Text(
                  'Hey, ${widget.uid}! Welcome to your personal finance management tool!',
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Times New Roman',
                  ),
                  textAlign: TextAlign.center,
                ),
                delay: 0,
              ),
              const SizedBox(height: 20),
              _buildAnimatedSection(
                const Text(
                  "Let's get started by setting up your preferences:",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Times New Roman',
                  ),
                ),
                delay: 1,
              ),
              const SizedBox(height: 10),
              _buildAnimatedSection(
                const Text(
                  'Currency:',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Times New Roman',
                  ),
                ),
                delay: 2,
              ),
              _buildAnimatedSection(
                Padding(
                  padding: const EdgeInsets.only(left: 86.0),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black, width: 1),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: DropdownButton<String>(
                      value: _selectedCurrency,
                      hint: const Text(
                        'Select Your Currency',
                        style: TextStyle(
                          fontFamily: 'Times New Roman',
                          color: Colors.black54,
                        ),
                      ),
                      onChanged: (String? newValue) {
                        setState(() {
                          _selectedCurrency = newValue;
                        });
                      },
                      items: _currencies.map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value.split(' - ')[0], // Use currency code as value
                          child: Text(
                            value,
                            style: const TextStyle(
                              fontFamily: 'Times New Roman',
                              color: Colors.black,
                            ),
                          ),
                        );
                      }).toList(),
                      style: const TextStyle(
                        fontFamily: 'Times New Roman',
                        color: Colors.black,
                      ),
                      dropdownColor: Colors.white,
                    ),
                  ),
                ),
                delay: 3,
              ),
              const SizedBox(height: 10),
              _buildAnimatedSection(
                const Text(
                  'Budget Type:',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Times New Roman',
                  ),
                ),
                delay: 4,
              ),
              _buildAnimatedSection(
                RadioListTile<String>(
                  title: const Text('Monthly', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: 'Monthly',
                  groupValue: _selectedBudgetType,
                  onChanged: (value) {
                    setState(() {
                      _selectedBudgetType = value!;
                    });
                  },
                ),
                delay: 5,
              ),
              _buildAnimatedSection(
                RadioListTile<String>(
                  title: const Text('Weekly', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: 'Weekly',
                  groupValue: _selectedBudgetType,
                  onChanged: (value) {
                    setState(() {
                      _selectedBudgetType = value!;
                    });
                  },
                ),
                delay: 5,
              ),
              _buildAnimatedSection(
                RadioListTile<String>(
                  title: const Text('Daily', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: 'Daily',
                  groupValue: _selectedBudgetType,
                  onChanged: (value) {
                    setState(() {
                      _selectedBudgetType = value!;
                    });
                  },
                ),
                delay: 5,
              ),
              const SizedBox(height: 10),
              _buildAnimatedSection(
                const Text(
                  'Notification Preferences:',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Times New Roman',
                  ),
                ),
                delay: 6,
              ),
              _buildAnimatedSection(
                CheckboxListTile(
                  title: const Text('Daily spending summary', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: _dailySummary,
                  onChanged: (bool? value) {
                    setState(() {
                      _dailySummary = value!;
                    });
                  },
                ),
                delay: 7,
              ),
              _buildAnimatedSection(
                CheckboxListTile(
                  title: const Text('Weekly budget status', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: _weeklyStatus,
                  onChanged: (bool? value) {
                    setState(() {
                      _weeklyStatus = value!;
                    });
                  },
                ),
                delay: 7,
              ),
              _buildAnimatedSection(
                CheckboxListTile(
                  title: const Text('Monthly expense analysis', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: _monthlyAnalysis,
                  onChanged: (bool? value) {
                    setState(() {
                      _monthlyAnalysis = value!;
                    });
                  },
                ),
                delay: 7,
              ),
              _buildAnimatedSection(
                CheckboxListTile(
                  title: const Text('Categorize expenses', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: _categorizeExpenses,
                  onChanged: (bool? value) {
                    setState(() {
                      _categorizeExpenses = value!;
                    });
                  },
                ),
                delay: 7,
              ),
              _buildAnimatedSection(
                CheckboxListTile(
                  title: const Text('Set spending limits', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: _setSpendingLimits,
                  onChanged: (bool? value) {
                    setState(() {
                      _setSpendingLimits = value!;
                    });
                  },
                ),
                delay: 7,
              ),
              _buildAnimatedSection(
                CheckboxListTile(
                  title: const Text('Track income sources', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: _trackIncomeSources,
                  onChanged: (bool? value) {
                    setState(() {
                      _trackIncomeSources = value!;
                    });
                  },
                ),
                delay: 7,
              ),
              _buildAnimatedSection(
                CheckboxListTile(
                  title: const Text('Create recurring expenses', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: _createRecurringExpenses,
                  onChanged: (bool? value) {
                    setState(() {
                      _createRecurringExpenses = value!;
                    });
                  },
                ),
                delay: 7,
              ),
              _buildAnimatedSection(
                CheckboxListTile(
                  title: const Text('Export data', style: TextStyle(fontFamily: 'Times New Roman')),
                  value: _exportData,
                  onChanged: (bool? value) {
                    setState(() {
                      _exportData = value!;
                    });
                  },
                ),
                delay: 7,
              ),
              const SizedBox(height: 20),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    // Navigate to the CategoriesPage
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => CategoriesPage(
                        uid: widget.uid,
                        selectedCurrency: _selectedCurrency ?? 'USD', // Default to USD if null
                      ),
                    ));
                  },
                  child: const Text('Next', style: TextStyle(fontFamily: 'Times New Roman')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
