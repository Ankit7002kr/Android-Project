import 'package:flutter/material.dart';
import 'package:animated_text_kit/animated_text_kit.dart'; // Import for animated text

class SignupPage extends StatefulWidget {
  @override
  _SignupPageState createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController contactNoController = TextEditingController();
  final TextEditingController occupationController = TextEditingController();
  final TextEditingController monthlyIncomeController = TextEditingController();
  final TextEditingController monthlyBudgetController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  void _handleSignup() {
    // Gather inputs
    String firstName = firstNameController.text.trim();
    String lastName = lastNameController.text.trim();
    String contactNo = contactNoController.text.trim();
    String occupation = occupationController.text.trim();
    String monthlyIncome = monthlyIncomeController.text.trim();
    String monthlyBudget = monthlyBudgetController.text.trim();
    String password = passwordController.text.trim();
    String confirmPassword = confirmPasswordController.text.trim();

    // Basic validation
    if (firstName.isEmpty ||
        lastName.isEmpty ||
        contactNo.isEmpty ||
        occupation.isEmpty ||
        monthlyIncome.isEmpty ||
        monthlyBudget.isEmpty ||
        password.isEmpty ||
        confirmPassword.isEmpty) {
      _showErrorSnackBar('Please fill all fields');
    } else if (password != confirmPassword) {
      _showErrorSnackBar('Passwords do not match');
    } else {
      _showSuccessSnackBar('Signup successful!');
      Future.delayed(Duration(seconds: 1), () {
        Navigator.pop(context); // Navigate back to login page
      });
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height, // Fill the entire screen height
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/img_10.png'), // Background image
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: MediaQuery.of(context).size.height * 0.05), // Top padding

                AnimatedTextKit(
                  animatedTexts: [
                    ColorizeAnimatedText(
                      'Xpenses',
                      textStyle: const TextStyle(
                        fontSize: 50,
                        fontFamily: 'Times New Roman',
                        fontWeight: FontWeight.bold,
                      ),
                      colors: [Colors.black, Colors.blue, Colors.purple, Colors.red],
                      speed: Duration(milliseconds: 500),
                    ),
                  ],
                  isRepeatingAnimation: true,
                  totalRepeatCount: 1000,
                ),
                SizedBox(height: 50), // Added gap between "Xpenses" and the first input field
                _buildTextField(firstNameController, 'First Name'),
                SizedBox(height: 15),
                _buildTextField(lastNameController, 'Last Name'),
                SizedBox(height: 15),
                _buildTextField(contactNoController, 'Contact No'),
                SizedBox(height: 15),
                _buildTextField(occupationController, 'Occupation'),
                SizedBox(height: 15),
                _buildTextField(monthlyIncomeController, 'Monthly Income'),
                SizedBox(height: 15),
                _buildTextField(monthlyBudgetController, 'Monthly Budget'),
                SizedBox(height: 15),
                _buildTextField(passwordController, 'Password', obscureText: true),
                SizedBox(height: 15),
                _buildTextField(confirmPasswordController, 'Confirm Password', obscureText: true),
                SizedBox(height: 25),
                ElevatedButton(
                  onPressed: _handleSignup,
                  child: Text('Signup', style: TextStyle(fontFamily: 'Times New Roman')),
                ),
                SizedBox(height: MediaQuery.of(context).size.height * 0.05), // Bottom padding
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, {bool obscureText = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.1), // Transparent container
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(color: Colors.black.withOpacity(0.5)),
      ),
      child: TextField(
        controller: controller,
        obscureText: obscureText,
        style: const TextStyle(
          color: Colors.black,  // Text color
          fontFamily: 'Times New Roman',
        ),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(
            color: Colors.black,  // Label color
            fontFamily: 'Times New Roman',
          ),
          border: InputBorder.none,
        ),
      ),
    );
  }
}
