import 'package:flutter/material.dart';
import 'welcomepage.dart';  // Ensure this page exists
import 'signup.dart';      // Import the signup.dart file correctly
import 'forgot.dart';      // Ensure this page exists
import 'package:animated_text_kit/animated_text_kit.dart';
import 'dart:math';  // Import Random class

class MyLogin extends StatefulWidget {
  const MyLogin({Key? key}) : super(key: key);

  @override
  _MyLoginState createState() => _MyLoginState();
}

class _MyLoginState extends State<MyLogin> with TickerProviderStateMixin {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController captchaController = TextEditingController(); // New controller for CAPTCHA
  String generatedCaptcha = ''; // Store generated CAPTCHA
  bool _rememberPassword = false;

  @override
  void initState() {
    super.initState();
    _generateCaptcha(); // Generate CAPTCHA when the page loads
  }

  // Function to generate a random 5-character alphanumeric CAPTCHA
  void _generateCaptcha() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    final random = Random();
    setState(() {
      generatedCaptcha = String.fromCharCodes(Iterable.generate(
        5,
            (_) => characters.codeUnitAt(random.nextInt(characters.length)),
      ));
    });
  }

  void _handleLogin() {
    String email = emailController.text;
    String password = passwordController.text;
    String enteredCaptcha = captchaController.text;

    if (email.isEmpty) {
      _showErrorSnackBar('Please enter email');
    } else if (password.isEmpty) {
      _showErrorSnackBar('Please enter password');
    } else if (enteredCaptcha.isEmpty || enteredCaptcha != generatedCaptcha) {
      _showCaptchaErrorDialog();  // Show alert dialog for incorrect CAPTCHA
      _generateCaptcha(); // Regenerate CAPTCHA on failure
    } else {
      _navigateToWelcomePage(email);
    }
  }

  // Function to navigate to the Welcome Page
  void _navigateToWelcomePage(String username) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => WelcomePage(uid: username),
      ),
    );
  }

  // Function to show the alert dialog for wrong CAPTCHA
  void _showCaptchaErrorDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            "Wrong CAPTCHA",
            style: TextStyle(
              fontFamily: 'Times New Roman',
              fontWeight: FontWeight.bold,
            ),
          ),
          content: const Text("The CAPTCHA you entered is incorrect. Please try again."),
          actions: <Widget>[
            ElevatedButton(
              onPressed: () {
                setState(() {});
                Navigator.of(context).pop(); // Close the dialog
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
              ),
              child: const Text("OK"),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  // Example: Reset CAPTCHA field
                });
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text("Cancel"),
            ),
          ],
        );
      },
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red, // Add background color to Snackbar
        duration: Duration(seconds: 3), // Increase duration for better visibility
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height, // Fill the entire screen height
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/img_16.png'), // Background image
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Colorize Animated Text for "Xpenses."
                AnimatedTextKit(
                  animatedTexts: [
                    ColorizeAnimatedText(
                      'Xpenses',
                      textStyle: const TextStyle(
                        fontSize: 80,
                        fontFamily: 'Times New Roman',
                        fontWeight: FontWeight.bold,
                      ),
                      colors: [
                        Colors.black,
                        Colors.blue,
                        Colors.purple,
                        Colors.red,
                      ],
                      speed: const Duration(milliseconds: 500),
                    ),
                  ],
                  isRepeatingAnimation: true,
                  totalRepeatCount: 1000,
                ),
                const SizedBox(height: 20),
                _buildTextField('Username', emailController, TextInputType.emailAddress, width: 370),
                const SizedBox(height: 20),
                _buildTextField('Password', passwordController, TextInputType.visiblePassword, obscureText: true, width: 370),
                const SizedBox(height: 10),

                // CAPTCHA Section
                const SizedBox(height: 10),
                Container(
                  width: 370, // Set the same width as other text fields
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.8), // Added opacity for better readability
                    borderRadius: BorderRadius.circular(20.0),
                    border: Border.all(color: Colors.black.withOpacity(0.5)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3), // Shadow position
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'CAPTCHA: ',
                            style: TextStyle(
                              color: Colors.black,
                              fontFamily: 'Times New Roman',
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            generatedCaptcha,
                            style: TextStyle(
                              color: Colors.black, // Changed to black for readability
                              fontFamily: 'Times New Roman',
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: captchaController,
                        keyboardType: TextInputType.text,
                        style: const TextStyle(
                          color: Colors.black, // Change text color to black
                          fontFamily: 'Times New Roman',
                        ),
                        decoration: InputDecoration(
                          labelText: 'Enter CAPTCHA',
                          labelStyle: const TextStyle(
                            color: Colors.black, // Change label color to black
                            fontFamily: 'Times New Roman',
                          ),
                          border: InputBorder.none,
                        ),
                      ),
                    ],
                  ),
                ),

                // Aligning "Forgot Password?" and "Remember Password"
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 33.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // "Forgot Password?" Text
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ForgotPasswordPage()),
                          );
                        },
                        child: const Text(
                          'Forgot Password?',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontFamily: 'Times New Roman',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      // "Remember Password" Checkbox
                      Row(
                        children: [
                          Checkbox(
                            value: _rememberPassword,
                            onChanged: (bool? newValue) {
                              setState(() {
                                _rememberPassword = newValue ?? false;
                              });
                            },
                          ),
                          const Text(
                            'Remember Password',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 14,
                              fontFamily: 'Times New Roman',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 10),

                // Login button
                ElevatedButton(
                  onPressed: _handleLogin,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15), backgroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  child: const Text(
                    'Log in',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontFamily: 'Times New Roman',
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // Login with options
                const Text(
                  'Or log in with:',
                  style: TextStyle(
                    fontSize: 16,
                    fontFamily: 'Times New Roman',
                  ),
                ),

                const SizedBox(height: 10),

                // Social Media Login Buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildSocialMediaButton('assets/img_9.png', () {
                      // Add Google login functionality
                    }),
                    const SizedBox(width: 10),
                    _buildSocialMediaButton('assets/img_8.png', () {
                      // Add Facebook login functionality
                    }),
                  ],
                ),

                const SizedBox(height: 20),

                // Navigate to Signup Page
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SignupPage()),
                    );
                  },
                  child: const Text(
                    'New here?Come join us then',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                      fontFamily: 'Times New Roman',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Widget for building social media login buttons
  Widget _buildSocialMediaButton(String imagePath, VoidCallback onPressed) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 5,
              spreadRadius: 2,
            ),
          ],
        ),
        child: ClipOval(
          child: Image.asset(
            imagePath,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String hintText, TextEditingController controller, TextInputType keyboardType,
      {bool obscureText = false, double width = double.infinity}) {
    return Container(
      width: width, // Set custom width
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.8), // Changed background color for better readability
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(color: Colors.black.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3), // Shadow position
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        obscureText: obscureText,
        keyboardType: keyboardType,
        style: const TextStyle(
          color: Colors.black, // Changed text color for better readability
          fontFamily: 'Times New Roman',
        ),
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: const TextStyle(
            color: Colors.black, // Changed hint color for consistency
            fontFamily: 'Times New Roman',
          ),
          border: InputBorder.none,
        ),
      ),
    );
  }
}
