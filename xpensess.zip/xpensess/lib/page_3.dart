import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'login.dart'; // Ensure this imports your login.dart

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Page3(),
    );
  }
}

class Page3 extends StatelessWidget {
  final String currentDate = DateFormat('dd/MM/yyyy').format(DateTime.now());
  final List<Expense> recentExpenses = [
    Expense('Groceries', 50, DateTime.now().subtract(Duration(days: 1))),
    Expense('Utilities', 30, DateTime.now().subtract(Duration(days: 2))),
    Expense('Dining Out', 20, DateTime.now().subtract(Duration(days: 3))),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
        backgroundColor: Colors.orange,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Welcome and Date
              Center(
                child: Column(
                  children: [
                    Text(
                      'Welcome to Your Expense Tracker',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Date: $currentDate',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[700],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),

              // Recent Expenses
              Text(
                'Recent Expenses',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              _buildRecentExpenses(),

              SizedBox(height: 20),

              // Add Expense Button
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context); // Navigate back to the previous page
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  'Add New Expense',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                  ),
                ),
              ),

              SizedBox(height: 10),

              // Home Button
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => MyLogin()), // Change to MyLogin
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  'Home',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Recent Expenses widget
  Widget _buildRecentExpenses() {
    return Column(
      children: recentExpenses.map((expense) {
        return ListTile(
          title: Text(expense.category),
          subtitle: Text(DateFormat('dd/MM/yyyy').format(expense.date)),
          trailing: Text('\$${expense.amount.toStringAsFixed(2)}'),
        );
      }).toList(),
    );
  }
}

// Expense data model
class Expense {
  final String category;
  final double amount;
  final DateTime date;

  Expense(this.category, this.amount, this.date);
}
