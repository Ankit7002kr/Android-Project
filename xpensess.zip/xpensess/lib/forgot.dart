import 'package:flutter/material.dart';
import 'login.dart'; // Ensure you import the LoginPage

class ForgotPasswordPage extends StatelessWidget {
  ForgotPasswordPage({Key? key}) : super(key: key);

  final TextEditingController mobileController = TextEditingController();
  final TextEditingController previousPasswordController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController reEnterPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Forgot Password'),
        backgroundColor: Colors.redAccent,
      ),
      body: Stack(
        children: [
          // Background image
          Positioned.fill(
            child: Image.asset(
              'assets/img_13.png',  // Ensure this path is correct and the image is in your assets folder
              fit: BoxFit.cover,
            ),
          ),
          // Transparent containers for the form
          Center(
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Registered mobile number field
                  Container(
                    width: 300,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.black),
                    ),
                    child: TextField(
                      controller: mobileController,
                      keyboardType: TextInputType.phone,
                      style: const TextStyle(fontFamily: 'Times New Roman'),
                      decoration: const InputDecoration(
                        hintText: 'Registered Mobile No.',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Previous password field
                  Container(
                    width: 300,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.black),
                    ),
                    child: TextField(
                      controller: previousPasswordController,
                      obscureText: true,
                      style: const TextStyle(fontFamily: 'Times New Roman'),
                      decoration: const InputDecoration(
                        hintText: 'Previous Password',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  // New password field
                  Container(
                    width: 300,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.black),
                    ),
                    child: TextField(
                      controller: newPasswordController,
                      obscureText: true,
                      style: const TextStyle(fontFamily: 'Times New Roman'),
                      decoration: const InputDecoration(
                        hintText: 'New Password',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Re-enter new password field
                  Container(
                    width: 300,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.black),
                    ),
                    child: TextField(
                      controller: reEnterPasswordController,
                      obscureText: true,
                      style: const TextStyle(fontFamily: 'Times New Roman'),
                      decoration: const InputDecoration(
                        hintText: 'Re-enter New Password',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  // Submit button
                  ElevatedButton(
                    onPressed: () {
                      // Validate input fields
                      if (mobileController.text.isEmpty ||
                          previousPasswordController.text.isEmpty ||
                          newPasswordController.text.isEmpty ||
                          reEnterPasswordController.text.isEmpty) {
                        // Show error message if any field is empty
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Please fill in all fields.')),
                        );
                      } else if (mobileController.text.length != 10) {
                        // Show error message if mobile number is not 10 digits
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Mobile number must be 10 digits.')),
                        );
                      } else if (newPasswordController.text != reEnterPasswordController.text) {
                        // Show error message if passwords do not match
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Passwords do not match.')),
                        );
                      } else {
                        // Navigate to the LoginPage when the button is pressed
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => MyLogin()),
                        );
                      }
                    },
                    child: const Text('Submit', style: TextStyle(fontFamily: 'Times New Roman')),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
