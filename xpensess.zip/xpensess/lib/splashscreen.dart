import 'package:flutter/material.dart';
import 'dart:async';
import 'login.dart'; // Import your login page

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Navigate to Login page after 3 seconds
    Timer(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => MyLogin()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue, // Set background color to blue
      body: Center(
        child: ClipOval(
          child: Image.asset(
            'assets/Gemini_Generated_Image_57eg4e57eg4e57eg_processed.jpeg',  // Path to your logo image
            width: 250,           // Adjust width to fit your design
            height: 250,          // Adjust height to fit your design
            fit: BoxFit.cover,    // Ensures the image fills the circular shape
          ),
        ),
      ),
    );
  }
}
