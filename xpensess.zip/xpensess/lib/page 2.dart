import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'page_3.dart'; // Import Page3 here

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Page2(),
    );
  }
}

class Page2 extends StatelessWidget {
  // Fetching current date and time
  final String currentDate = DateFormat('dd/MM/yyyy').format(DateTime.now());
  final String currentTime = DateFormat('HH:mm').format(DateTime.now());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/img_13.png'), // Add your background image here
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Main content
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SizedBox(height: 20),
                  Center(
                    child: Text(
                      'Add your expenses',
                      style: TextStyle(
                        fontSize: 40, // Increased font size
                        fontFamily: 'Times New Roman',
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Center(
                    child: Text(
                      'Date: $currentDate', // Dynamic current date
                      style: TextStyle(
                        fontSize: 18,
                        fontFamily: 'Times New Roman',
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Center(
                    child: Text(
                      'Time: $currentTime', // Dynamic current time
                      style: TextStyle(
                        fontSize: 18,
                        fontFamily: 'Times New Roman',
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  _buildInputField(context, 'Amount'),
                  SizedBox(height: 20),
                  _buildInputField(context, 'Category'),
                  SizedBox(height: 20),
                  _buildInputField(context, 'Reason'),
                  SizedBox(height: 20),
                  _buildInputField(context, 'Account'),
                  SizedBox(height: 20),
                  _buildInputField(context, 'Description'), // New Description field
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 20.0),
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to Page3 when Done is pressed
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Page3()), // Navigate to Page3
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange, // Button color
                        padding: EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text(
                        'Done',
                        style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Times New Roman',
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField(BuildContext context, String label) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.8),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white),
      ),
      child: TextField(
        style: TextStyle(color: Colors.white, fontFamily: 'Times New Roman'),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.white, fontFamily: 'Times New Roman'),
          border: InputBorder.none,
        ),
      ),
    );
  }
}
